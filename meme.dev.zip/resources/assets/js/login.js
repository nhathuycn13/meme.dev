/**
 *
 * Created by huy on 23/10/16.
 */

require('./bootstrap');

new Vue({
    el : '#app',

});
