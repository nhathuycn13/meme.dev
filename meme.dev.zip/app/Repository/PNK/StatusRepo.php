<?php
/**
 * Created by PhpStorm.
 * User: huy
 * Date: 02/11/16
 * Time: 17:45
 */

namespace App\Repository\PNK;


interface StatusRepo
{
    public function getAll();
}