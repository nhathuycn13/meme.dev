<?php
/**
 * Created by PhpStorm.
 * User: huy
 * Date: 08/11/16
 * Time: 15:14
 */

namespace App\Repository\Tax;


class TaxEloquent
{
    private $tax;

    /**
     * @inheritDoc
     */
    public function __construct() { }

}